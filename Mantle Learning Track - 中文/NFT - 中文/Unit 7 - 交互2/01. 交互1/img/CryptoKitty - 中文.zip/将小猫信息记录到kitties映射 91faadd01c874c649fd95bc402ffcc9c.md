# 将小猫信息记录到kitties映射

# Content/将小猫信息记录到kitties映射

在***_createKitty***函数中，首先我们需要将小猫的信息存储到新创建的***kitties***映射中。

我们已经通过参数获得了以下信息：

1. 猫妈妈的TokenId
2. 猫爸爸的TokenId
3. 迭代数
4. 基因
5. 猫主人

为了创建一个完整的***Kitty***结构体，我们还需要一个属性：***birthTime***，即小猫的出生时间。在区块链中，我们可以使用block.timestamp语法来获取当前区块的时间。

一旦我们拥有了***Kitty***结构体中的所有信息，就可以创建一个新的小猫。接下来，我们只需将要铸造的NFT的TokenId与这个新小猫关联起来即可。

**Syntax**

mapping

- 提示
    
    
    ```solidity
    //例如这里就将studentId和学生信息一一对应起来
    students[studentId] = Student(name,classId);
    ```
    

# Quiz/TODO

# QuizA

1. 根据参数信息创建***Kitty***结构体，并将其赋值给***_tokenIdCounter***所对应的***kitties***映射。

```solidity
pragma solidity 0.8.17;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";

contract SimpleCryptoKitties is ERC721 {
  uint256 public _tokenIdCounter = 1;

  struct Kitty {
    uint256 genes;
    uint256 birthTime;
    uint256 momId;
    uint256 dadId;
    uint256 generation;
  }

  mapping(uint256 => Kitty) public kitties;

  constructor() ERC721("SimpleCryptoKitties", "SCK") {}

  function _createKitty(
    uint256 momId,
    uint256 dadId,
    uint256 generation,
    uint256 genes,
    address owner
  ) private returns (uint256) {
    @@@
    kitties[_tokenIdCounter] = Kitty(
      genes,
      block.timestamp,
      momId,
      dadId,
      generation
    );
    ###

    //regex starts here
    ^kitties\[\s*\_tokenIdCounter\s*\]\s*\=\s*Kitty\(\s*genes\,\s*block\.timestamp\,\s*momId\,\s*dadId\,\s*generation\s*\)\s*;\s*$
    //regex ends here
  }
}
```

[Lesson Info](Lesson%20Info%20586915a726854c8db1b462465fa1e528.csv)