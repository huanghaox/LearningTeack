# 创建创世小猫

Description: 完成第一个public函数——创建一个初代小猫
UUID: d6ff7b26e14945eabb36160a4b339eca