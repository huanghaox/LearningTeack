# 定义breed函数

# Content/定义breed函数

我们现在来定义***breed***函数。首先，你需要明白这个函数的目的：它是为了根据指定的猫妈妈和猫爸爸孕育出下一代小猫，而这只小猫的基因与其父母有关。

因此，我们需要为猫爸和猫妈定义两个*uint256*类型的参数，这样我们可以查询他们的基本信息。

关于函数的可见性，我们选择`public`，因为我们希望这个函数无论在合约内部还是外部都可以被调用。

**Syntax**

function,scope

- 提示
    
    ```solidity
    function breed(uint256 momId, uint256 dadId) public returns (uint256) { }
    ```
    

# Quiz/TODO

# QuizA

1. 定义一个名为***breed***的函数，参数分别为*uint256*类型的*momId*和*dadId*，可见性为`public`，返回值为*uint256*。

```solidity
pragma solidity 0.8.17;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";

contract SimpleCryptoKitties is ERC721 {
  uint256 public _tokenIdCounter = 1;

  struct Kitty {
    uint256 genes;
    uint256 birthTime;
    uint256 momId;
    uint256 dadId;
    uint256 generation;
  }

  mapping(uint256 => Kitty) public kitties;

  constructor() ERC721("SimpleCryptoKitties", "SCK") {}

  function createKittyGen0() public returns (uint256) {
    uint256 genes = uint256(
      keccak256(abi.encodePacked(block.timestamp, _tokenIdCounter))
    );
    return _createKitty(0, 0, 0, genes, msg.sender);
  }

  function _createKitty(
    uint256 momId,
    uint256 dadId,
    uint256 generation,
    uint256 genes,
    address owner
  ) private returns (uint256) {
    kitties[_tokenIdCounter] = Kitty(
      genes,
      block.timestamp,
      momId,
      dadId,
      generation
    );
    _mint(owner, _tokenIdCounter);
    return _tokenIdCounter++;
  }

  @@@
  function breed(uint256 momId, uint256 dadId) public returns (uint256) {}
  ###

  //regex starts here
  ^function\s+breed\s*\(\s*uint256\s+momId\s*\,\s*uint256\s+dadId\s*\)\s*public\s+returns\s*\(\s*uint256\s*\)\s*\{\s*\}\s*$
  //regex ends here
}
```

[Lesson Info](Lesson%20Info%20bc765b4e8cd84234908b99f9861e16b7.csv)