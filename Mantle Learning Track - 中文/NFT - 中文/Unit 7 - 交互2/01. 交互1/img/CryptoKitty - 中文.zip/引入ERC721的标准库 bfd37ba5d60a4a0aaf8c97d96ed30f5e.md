# 引入ERC721的标准库

Generator: bfd37ba5d60a4a0aaf8c97d96ed30f5e
Style: A
UUID: 1fd3445d2565406694ab168006f849aa