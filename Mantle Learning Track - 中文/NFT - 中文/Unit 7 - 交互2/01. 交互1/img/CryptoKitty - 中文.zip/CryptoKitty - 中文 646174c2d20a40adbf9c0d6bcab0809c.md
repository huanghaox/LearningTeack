# CryptoKitty - 中文

Description: 如果你是位Web3-native的用户，你大概率听说过 CryptoKitty。CryptoKitty 是世界上最早的区块链游戏之一，玩家可以购买、饲养和交易具有不同视觉特征、不同稀有程度的虚拟猫咪。2017 年 12 月，这款游戏大受欢迎，将以太坊网络的交易数量推向了历史新高，最高曾占超过 10%的网络流量比例。在 CryptoKitty 课程中，我们将学习如何复刻这个爆款产品。也许，这门课会启发你创造出属于自己的爆款区块链游戏！
Duration: 90
Language: Solidity
Level: Beginner
Track: NFT
Type: Guided Project
UUID: dbb4d045366740afb322220794a400f3