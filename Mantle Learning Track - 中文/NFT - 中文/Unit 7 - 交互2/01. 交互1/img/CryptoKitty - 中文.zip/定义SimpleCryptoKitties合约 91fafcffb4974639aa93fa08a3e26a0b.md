# 定义SimpleCryptoKitties合约

# Content/定义SimpleCryptoKitties合约

在项目的开头，我们首先来定义合约。

刚刚我们提到***CryptoKitties***其实是一个遵循ERC721的NFT，所以我们在定义合约时，需要继承ERC721的标准合约。

> 如果你对ERC721，NFT还没有了解，可以移步我们的NFT教程
> 

**Syntax**

contract,inherit

- 提示
    
    ```solidity
    contract CryptoKitties is ERC721 {}
    ```
    

# Quiz/TODO

# QuizA

1. 定义一个***SimpleCryptoKitties*** 合约，并继承 ERC721 合约

```solidity
pragma solidity 0.8.17;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";

@@@
contract SimpleCryptoKitties is ERC721 { }
###

//regex starts here
^contract\s+SimpleCryptoKitties\s+is\s+ERC721\s*\{\s*\}$
//regex ends here
```

[Lesson Info](Lesson%20Info%20ff8785315c7a4e188ba28440fa72e555.csv)