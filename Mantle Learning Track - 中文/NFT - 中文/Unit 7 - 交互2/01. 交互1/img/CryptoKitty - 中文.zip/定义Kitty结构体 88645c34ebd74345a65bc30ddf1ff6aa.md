# 定义Kitty结构体

UUID: 7caa069066dd428a897cb039ec76f6fb