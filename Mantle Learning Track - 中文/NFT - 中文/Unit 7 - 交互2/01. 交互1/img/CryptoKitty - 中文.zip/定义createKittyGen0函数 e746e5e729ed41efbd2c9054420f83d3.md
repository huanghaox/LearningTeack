# 定义createKittyGen0函数

# Content/定义createKittyGen0函数

非常好！在上一章中，我们已经定义了所需的变量。现在，让我们开始创建一个初代小猫。

首先，我们要定义一个名为***createKittyGen0***的函数。理解这个函数的目的是关键：它的任务是随机生成一个初代小猫。这个小猫的基因是随机的，父母信息为空，迭代数为*0*，出生时间则是当前区块的时间戳。这些组成了初代小猫的基本信息。

我们希望用户在创建随机的初代小猫后能知道自己创建的小猫的TokenId，因此这个函数需要返回一个值，即新创建的小猫的TokenId。

关于函数的可见性，我们选择`public`，因为我们希望这个函数可以在任何地方被调用，以创建一个初代小猫。

**Syntax**

function, scope, return

- 提示
    
    ```solidity
    function createKittyGen0() public returns (uint256) { }
    ```
    

# Quiz/TODO

# QuizA

1. 定义一个名为***createKittyGen0***的函数，可见性为`public`，有一个*uint256*类型的返回值。

```solidity
pragma solidity 0.8.17;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";

contract SimpleCryptoKitties is ERC721 {
  uint256 public _tokenIdCounter = 1;

  struct Kitty {
    uint256 genes;
    uint256 birthTime;
    uint256 momId;
    uint256 dadId;
    uint256 generation;
  }

  mapping(uint256 => Kitty) public kitties;

  constructor() ERC721("SimpleCryptoKitties", "SCK") {}

  @@@
  function createKittyGen0() public returns (uint256) {}
  ###

  //regex starts here
  ^function\s+createKittyGen0\s*\(\s*\)\s*public\s+returns\s*\(\s*uint256\s*\)\s*\{\s*\}\s*$
  //regex ends here

  function _createKitty(
    uint256 momId,
    uint256 dadId,
    uint256 generation,
    uint256 genes,
    address owner
  ) private returns (uint256) {
    kitties[_tokenIdCounter] = Kitty(
      genes,
      block.timestamp,
      momId,
      dadId,
      generation
    );
    _mint(owner, _tokenIdCounter);
    return _tokenIdCounter++;
  }
}
```

[Lesson Info](Lesson%20Info%20fb090ae5523e4797aec10d7692f56c46.csv)